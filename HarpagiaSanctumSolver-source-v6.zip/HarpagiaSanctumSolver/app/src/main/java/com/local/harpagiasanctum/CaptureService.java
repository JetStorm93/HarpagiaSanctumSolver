package com.local.harpagiasanctum;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.nio.ByteBuffer;

public class CaptureService extends Service {
    public static final String ACTION_START = "com.local.harpagiasanctum.action.START_CAPTURE";
    public static final String ACTION_STOP = "com.local.harpagiasanctum.action.STOP_CAPTURE";
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";

    private static final String CHANNEL_ID = "sanctum_capture";
    private static final int NOTIFICATION_ID = 52;
    private static final long MIN_FRAME_INTERVAL_MS = 32L;

    private static volatile CaptureService instance;
    private static volatile FrameListener frameListener;

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread captureThread;
    private Handler captureHandler;
    private int width;
    private int height;
    private int densityDpi;
    private long lastDeliveredFrame;

    public interface FrameListener {
        void onFrame(ScreenFrame frame);
        void onCaptureStopped();
    }

    /** Lightweight read-only view of one ImageReader frame. Valid only during onFrame(). */
    public static final class ScreenFrame {
        public final int width;
        public final int height;
        private final ByteBuffer buffer;
        private final int rowStride;
        private final int pixelStride;

        ScreenFrame(Image image, int width, int height) {
            this.width = width;
            this.height = height;
            Image.Plane plane = image.getPlanes()[0];
            this.buffer = plane.getBuffer();
            this.rowStride = plane.getRowStride();
            this.pixelStride = plane.getPixelStride();
        }

        /** Returns packed 0xRRGGBB. */
        public int rgb(int x, int y) {
            if (x < 0) x = 0;
            else if (x >= width) x = width - 1;
            if (y < 0) y = 0;
            else if (y >= height) y = height - 1;
            int p = y * rowStride + x * pixelStride;
            int r = buffer.get(p) & 0xff;
            int g = buffer.get(p + 1) & 0xff;
            int b = buffer.get(p + 2) & 0xff;
            return (r << 16) | (g << 8) | b;
        }
    }

    public static boolean isRunning() {
        CaptureService s = instance;
        return s != null && s.projection != null && s.imageReader != null;
    }

    public static void setFrameListener(FrameListener listener) {
        frameListener = listener;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) {
            releaseCapture(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(action)) {
            startAsForeground();
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
            Intent resultData = getResultData(intent);
            if (resultCode == Activity.RESULT_OK && resultData != null) {
                startProjection(resultCode, resultData);
            } else {
                stopSelf();
            }
        }
        return START_NOT_STICKY;
    }

    @SuppressWarnings("deprecation")
    private Intent getResultData(Intent intent) {
        if (Build.VERSION.SDK_INT >= 33) {
            return intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        }
        return intent.getParcelableExtra(EXTRA_RESULT_DATA);
    }

    private void startAsForeground() {
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Harpagia Sanctum Solver")
                .setContentText("Watching the screen for the Sanctum code puzzle")
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void startProjection(int resultCode, Intent data) {
        releaseCapture(false);
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (manager == null) return;

        resolveScreenSize();
        captureThread = new HandlerThread("HarpagiaSanctumCapture");
        captureThread.start();
        captureHandler = new Handler(captureThread.getLooper());

        projection = manager.getMediaProjection(resultCode, data);
        if (projection == null) return;
        final MediaProjection registeredProjection = projection;
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                // Ignore a delayed callback from an older projection after a new session starts.
                if (projection == registeredProjection) {
                    projection = null;
                    releaseCapture(true);
                }
            }
        }, captureHandler);

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        imageReader.setOnImageAvailableListener(this::onImageAvailable, captureHandler);
        virtualDisplay = projection.createVirtualDisplay(
                "HarpagiaZenCapture",
                width,
                height,
                densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                captureHandler);
    }

    private void onImageAvailable(ImageReader reader) {
        Image image = reader.acquireLatestImage();
        if (image == null) return;
        try {
            FrameListener listener = frameListener;
            if (listener == null) return;
            long now = SystemClock.elapsedRealtime();
            if (now - lastDeliveredFrame < MIN_FRAME_INTERVAL_MS) return;
            lastDeliveredFrame = now;
            listener.onFrame(new ScreenFrame(image, width, height));
        } catch (Throwable ignored) {
            // A malformed/transient frame should not stop the capture service.
        } finally {
            image.close();
        }
    }

    private void resolveScreenSize() {
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        densityDpi = dm.densityDpi;
        if (wm != null && Build.VERSION.SDK_INT >= 30) {
            Rect bounds = wm.getMaximumWindowMetrics().getBounds();
            width = bounds.width();
            height = bounds.height();
        } else if (wm != null) {
            DisplayMetrics real = new DisplayMetrics();
            //noinspection deprecation
            wm.getDefaultDisplay().getRealMetrics(real);
            width = real.widthPixels;
            height = real.heightPixels;
            densityDpi = real.densityDpi;
        } else {
            width = dm.widthPixels;
            height = dm.heightPixels;
        }
    }

    private void releaseCapture(boolean notifyListener) {
        if (virtualDisplay != null) {
            try { virtualDisplay.release(); } catch (Throwable ignored) {}
            virtualDisplay = null;
        }
        if (imageReader != null) {
            try { imageReader.close(); } catch (Throwable ignored) {}
            imageReader = null;
        }
        if (projection != null) {
            MediaProjection p = projection;
            projection = null;
            try { p.stop(); } catch (Throwable ignored) {}
        }
        if (captureThread != null) {
            try { captureThread.quitSafely(); } catch (Throwable ignored) {}
            captureThread = null;
            captureHandler = null;
        }
        if (notifyListener) {
            FrameListener listener = frameListener;
            if (listener != null) {
                try { listener.onCaptureStopped(); } catch (Throwable ignored) {}
            }
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Sanctum screen capture",
                NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Required while Harpagia Sanctum Solver is reading the screen.");
        nm.createNotificationChannel(channel);
    }

    @Override
    public void onDestroy() {
        releaseCapture(true);
        if (instance == this) instance = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
