# Harpagia Sanctum Solver

Private Android helper for Harpagia's Sanctum / Insight code puzzle.

## What v0.2 does
- Uses MediaProjection to read only the visible screen.
- Uses an AccessibilityService only to show a floating START/STOP button and dispatch taps.
- Dynamically finds the row of blue numeric buttons and the green Confirm button.
- Ignores the gray `?` button.
- Starts with the visible numbers in order, e.g. `0 1 2 3 4`.
- Reads the newest green-check exact-position count from the guess history using color/shape matching; no OCR library is required.
- Infers the red-X count as `code length - green`, avoiding false reads such as X5 when the visible buttons are only 0-4.
- Filters all remaining permutation candidates consistent with the feedback.
- Chooses a next guess by minimizing the largest possible remaining candidate bucket (with a secondary expected-size tie break).
- Repeats until solved or stopped.

## Current rule assumption
This build assumes each visible blue number is used exactly once in the hidden code. Under that rule, green + red always equals the code length, so only the green count is required for deduction. The red line is still detected as a row anchor but its digit is not needed.

The detector was checked against the supplied 709x1536 Sanctum screenshots: it found the 5 numeric buttons, Confirm button, and read the shown feedback as green=3 / red=2.

## Build
The project targets Android SDK 35 and Java 17. The included debug signing key is intentionally stable so future APKs from this project can update the installed app instead of conflicting with a new ephemeral GitHub Actions debug key.


## v0.2 fixes
- Fixes `✓0 / X5` being misread as `✓0 / X0`.
- Removes the unnecessary old-feedback pre-scan so the first guess begins sooner after START.


## v0.3.0
- Moved the floating solver control about 65 dp higher so it blocks less of the Sanctum UI.
