package com.local.harpagiasanctum;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.Toast;

public class SanctumAccessibilityService extends AccessibilityService implements CaptureService.FrameListener {
    private static final long TAP_DURATION_MS = 45L;
    private static final long BETWEEN_DIGITS_MS = 115L;
    private static final long BEFORE_CONFIRM_MS = 100L;
    private static final long AFTER_CONFIRM_IGNORE_MS = 160L;
    private static final long FEEDBACK_SCAN_INTERVAL_MS = 45L;
    private static final long MOVED_HISTORY_ACCEPT_MS = 220L;
    private static final long SAME_HISTORY_FALLBACK_MS = 520L;
    private static final long NEXT_GUESS_DELAY_MS = 60L;
    private static final long DETECT_INTERVAL_MS = 90L;

    private enum State { OFF, DETECTING, SUBMITTING, WAITING_RESULT, THINKING }

    private final Object stateLock = new Object();
    private final Handler main = new Handler(Looper.getMainLooper());

    private WindowManager windowManager;
    private Button controlButton;
    private WindowManager.LayoutParams overlayParams;

    private volatile State state = State.OFF;
    private SanctumDetector.Layout layout;
    private PermutationSolver solver;
    private int[] currentGuess;
    private int guessNumber;
    private int runToken;
    private int lastFeedbackY = -1;
    private int lastFeedbackGreen = -1;
    private int lastFeedbackRed = -1;
    private long confirmSubmittedAt;
    private long resultReadableAfter;
    private long lastFeedbackScan;
    private long lastDetectAttempt;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        CaptureService.setFrameListener(this);
        showOverlay();
    }

    private void showOverlay() {
        if (controlButton != null) return;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (windowManager == null) return;

        controlButton = new Button(this);
        controlButton.setText("SANCTUM\nSTART");
        controlButton.setTextColor(Color.WHITE);
        controlButton.setTextSize(10);
        controlButton.setAllCaps(false);
        controlButton.setGravity(Gravity.CENTER);
        controlButton.setPadding(dp(4), 0, dp(4), 0);
        applyButtonColor(Color.rgb(19, 132, 112));
        controlButton.setOnClickListener(v -> toggle());
        controlButton.setOnLongClickListener(v -> {
            restartFresh();
            return true;
        });

        overlayParams = new WindowManager.LayoutParams(
                dp(116),
                dp(68),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                android.graphics.PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.START;
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        overlayParams.x = Math.max(dp(8), screenWidth - dp(126));
        overlayParams.y = dp(190);
        windowManager.addView(controlButton, overlayParams);
    }

    private void toggle() {
        if (state == State.OFF) startSolver();
        else stopSolver("Sanctum solver stopped.");
    }

    private void restartFresh() {
        if (state == State.OFF) {
            startSolver();
            return;
        }
        synchronized (stateLock) {
            runToken++;
            state = State.DETECTING;
            layout = null;
            solver = null;
            currentGuess = null;
            guessNumber = 0;
            lastFeedbackY = -1;
            lastFeedbackGreen = -1;
            lastFeedbackRed = -1;
            confirmSubmittedAt = 0L;
            lastDetectAttempt = 0L;
        }
        setButton("STOP\nFIND…", Color.rgb(220, 145, 35));
        toast("Deduction history cleared. Start from a fresh Sanctum puzzle.");
    }

    private void startSolver() {
        if (!CaptureService.isRunning()) {
            toast("Open Harpagia Sanctum Solver and start screen capture first.");
            return;
        }
        synchronized (stateLock) {
            runToken++;
            state = State.DETECTING;
            layout = null;
            solver = null;
            currentGuess = null;
            guessNumber = 0;
            lastFeedbackY = -1;
            lastFeedbackGreen = -1;
            lastFeedbackRed = -1;
            confirmSubmittedAt = 0L;
            lastDetectAttempt = 0L;
        }
        CaptureService.setFrameListener(this);
        setButton("STOP\nFIND…", Color.rgb(220, 145, 35));
    }

    private void stopSolver(String message) {
        synchronized (stateLock) {
            runToken++;
            state = State.OFF;
            layout = null;
            solver = null;
            currentGuess = null;
            guessNumber = 0;
            lastFeedbackY = -1;
            lastFeedbackGreen = -1;
            lastFeedbackRed = -1;
            confirmSubmittedAt = 0L;
        }
        setButton("SANCTUM\nSTART", Color.rgb(19, 132, 112));
        if (message != null) toast(message);
    }

    @Override
    public void onFrame(CaptureService.ScreenFrame frame) {
        State local = state;
        if (local == State.OFF || local == State.SUBMITTING || local == State.THINKING) return;

        long now = SystemClock.elapsedRealtime();
        if (local == State.DETECTING) {
            if (now - lastDetectAttempt < DETECT_INTERVAL_MS) return;
            lastDetectAttempt = now;
            detectAndBegin(frame);
            return;
        }

        if (local == State.WAITING_RESULT) {
            if (now < resultReadableAfter || now - lastFeedbackScan < FEEDBACK_SCAN_INTERVAL_MS) return;
            lastFeedbackScan = now;
            readResult(frame);
        }
    }

    private void detectAndBegin(CaptureService.ScreenFrame frame) {
        try {
            SanctumDetector.Layout found = SanctumDetector.detect(frame);
            if (found.count < 3 || found.count > 8) return;

            // Start immediately once the puzzle controls are found. The feedback reader always
            // chooses the lowest/newest visible result row, so a costly pre-scan of old history is
            // unnecessary and only delays the first guess.
            int[] first;
            int token;
            synchronized (stateLock) {
                if (state != State.DETECTING) return;
                layout = found;
                solver = new PermutationSolver(found.count);
                first = solver.firstGuess();
                currentGuess = first;
                guessNumber = 1;
                lastFeedbackY = found.feedbackStartY - 1;
                lastFeedbackGreen = -1;
                lastFeedbackRed = -1;
                confirmSubmittedAt = 0L;
                state = State.SUBMITTING;
                token = runToken;
            }
            setButton("STOP " + found.count + "#\nGUESS 1", Color.rgb(29, 118, 210));
            toast("Sanctum detected: " + found.count + " positions. Submitting first guess.");
            final int[] firstCopy = first.clone();
            final int run = token;
            main.post(() -> submitGuess(firstCopy, 0, run));
        } catch (SanctumDetector.DetectionException ignored) {
            // Keep looking while the user navigates to the puzzle.
        } catch (Throwable t) {
            stopSolver("Sanctum detection failed. Long-press START to retry.");
        }
    }

    private void submitGuess(int[] guess, int index, int token) {
        SanctumDetector.Layout l = layout;
        synchronized (stateLock) {
            if (state != State.SUBMITTING || token != runToken || l == null) return;
        }

        if (index < guess.length) {
            int digit = guess[index];
            if (digit < 0 || digit >= l.numberX.length) {
                stopSolver("Solver generated an unavailable number.");
                return;
            }
            setButton("STOP " + l.count + "#\nTAP " + (index + 1) + "/" + guess.length,
                    Color.rgb(29, 118, 210));
            dispatchTap(l.numberX[digit], l.numberY, () ->
                    main.postDelayed(() -> submitGuess(guess, index + 1, token), BETWEEN_DIGITS_MS));
            return;
        }

        setButton("STOP\nCONFIRM", Color.rgb(29, 118, 210));
        main.postDelayed(() -> dispatchTap(l.confirmX, l.confirmY, () -> {
            synchronized (stateLock) {
                if (state != State.SUBMITTING || token != runToken) return;
                state = State.WAITING_RESULT;
                confirmSubmittedAt = SystemClock.elapsedRealtime();
                resultReadableAfter = confirmSubmittedAt + AFTER_CONFIRM_IGNORE_MS;
                lastFeedbackScan = 0L;
            }
            setButton("STOP\nREAD…", Color.rgb(220, 145, 35));
        }), BEFORE_CONFIRM_MS);
    }

    private void readResult(CaptureService.ScreenFrame frame) {
        SanctumDetector.Layout l = layout;
        PermutationSolver s = solver;
        int[] guess = currentGuess;
        if (l == null || s == null || guess == null) return;

        SanctumDetector.Feedback f = l.readLatestFeedback(frame);
        if (f == null) return;

        // Normally a new history row appears lower than the previous one. After several guesses,
        // however, Harpagia can reposition/scroll the history. The old v0.3 logic required every
        // row to have a larger Y coordinate, which could make the solver appear to stop around
        // guess five. Prefer the normal lower-row signal, but allow a moved row quickly when its
        // score changes and use a short timed fallback when the new row lands in the same place
        // with the same score.
        long sinceConfirm = Math.max(0L, SystemClock.elapsedRealtime() - confirmSubmittedAt);
        boolean firstResult = guessNumber <= 1 || lastFeedbackGreen < 0;
        boolean clearlyLower = f.rowY > lastFeedbackY + 6;
        boolean signatureChanged = f.green != lastFeedbackGreen ||
                f.red != lastFeedbackRed || Math.abs(f.rowY - lastFeedbackY) > 6;
        if (!firstResult && !clearlyLower) {
            if (signatureChanged) {
                if (sinceConfirm < MOVED_HISTORY_ACCEPT_MS) return;
            } else if (sinceConfirm < SAME_HISTORY_FALLBACK_MS) {
                return;
            }
        }

        // The deduction engine currently models Sanctum as a permutation: every visible blue
        // number appears exactly once. Under that rule G + X must always equal the code length.
        // v0.4 reads both counters independently so a rule mismatch is detected instead of silently
        // making bad deductions.
        if (f.green < 0 || f.red < 0 || f.green > l.count || f.red > l.count) return;
        if (f.green + f.red != l.count) {
            stopSolver("Rule mismatch: game showed G" + f.green + " X" + f.red +
                    " for " + l.count + " slots. Send a screenshot.");
            return;
        }

        lastFeedbackY = f.rowY;
        lastFeedbackGreen = f.green;
        lastFeedbackRed = f.red;
        if (f.green == l.count) {
            stopSolver("Solved in " + guessNumber + " guesses.");
            return;
        }

        synchronized (stateLock) {
            if (state != State.WAITING_RESULT) return;
            state = State.THINKING;
        }
        setButton("STOP\nTHINK…", Color.rgb(126, 85, 180));

        try {
            s.applyFeedback(guess, f.green);
            int remaining = s.remainingCount();
            if (remaining <= 0) {
                stopSolver("No possible codes remain. Send a screenshot of the last feedback.");
                return;
            }
            int[] next = s.chooseNextGuess();
            if (next == null) {
                stopSolver("No next guess could be generated.");
                return;
            }

            int token;
            synchronized (stateLock) {
                if (state != State.THINKING) return;
                currentGuess = next;
                guessNumber++;
                state = State.SUBMITTING;
                token = runToken;
            }
            setButton("STOP G" + f.green + " X" + f.red + "\n" + remaining + " LEFT",
                    s.isCertain() ? Color.rgb(44, 150, 84) : Color.rgb(29, 118, 210));
            final int[] nextCopy = next.clone();
            final int run = token;
            main.postDelayed(() -> submitGuess(nextCopy, 0, run), NEXT_GUESS_DELAY_MS);
        } catch (Throwable t) {
            stopSolver("Deduction error. Send a screenshot of the current Sanctum board.");
        }
    }

    private void dispatchTap(float x, float y, Runnable after) {
        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x + 0.1f, y + 0.1f);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, TAP_DURATION_MS))
                .build();
        boolean accepted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription gestureDescription) {
                if (after != null) after.run();
            }

            @Override
            public void onCancelled(GestureDescription gestureDescription) {
                stopSolver("Android cancelled a Sanctum tap.");
            }
        }, main);
        if (!accepted) stopSolver("Android rejected a Sanctum tap.");
    }

    @Override
    public void onCaptureStopped() {
        main.post(() -> stopSolver("Screen capture stopped. Start it again in Harpagia Sanctum Solver."));
    }

    private void setButton(String text, int color) {
        main.post(() -> {
            if (controlButton == null) return;
            controlButton.setText(text);
            applyButtonColor(color);
        });
    }

    private void applyButtonColor(int color) {
        if (controlButton == null) return;
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), Color.argb(185, 255, 255, 255));
        controlButton.setBackground(bg);
    }

    private void toast(String text) {
        main.post(() -> Toast.makeText(this, text, Toast.LENGTH_LONG).show());
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        // Screen analysis is intentionally performed through MediaProjection rather than app internals.
    }

    @Override public void onInterrupt() {}

    @Override
    public void onDestroy() {
        CaptureService.setFrameListener(null);
        synchronized (stateLock) {
            state = State.OFF;
            runToken++;
        }
        if (controlButton != null && windowManager != null) {
            try { windowManager.removeView(controlButton); } catch (Throwable ignored) {}
            controlButton = null;
        }
        super.onDestroy();
    }
}
