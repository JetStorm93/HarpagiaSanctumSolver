package com.local.harpagiasanctum;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Pure deduction engine for a permutation-style Mastermind puzzle. */
public final class PermutationSolver {
    private final int size;
    private final ArrayList<int[]> allPermutations = new ArrayList<>();
    private final ArrayList<int[]> candidates = new ArrayList<>();
    private final Set<String> usedGuesses = new HashSet<>();

    public PermutationSolver(int size) {
        if (size < 2 || size > 8) throw new IllegalArgumentException("Unsupported code size: " + size);
        this.size = size;
        int[] seed = new int[size];
        for (int i = 0; i < size; i++) seed[i] = i;
        permute(seed, 0, allPermutations);
        for (int[] p : allPermutations) candidates.add(p.clone());
    }

    public int size() { return size; }
    public int remainingCount() { return candidates.size(); }

    public int[] firstGuess() {
        int[] g = new int[size];
        for (int i = 0; i < size; i++) g[i] = i;
        usedGuesses.add(key(g));
        return g;
    }

    /** Applies one green-check count. Red is redundant when every visible symbol is used once. */
    public int remainingIfFeedback(int[] guess, int exactMatches) {
        if (guess == null || guess.length != size) return 0;
        if (exactMatches < 0 || exactMatches > size) return 0;
        int count = 0;
        for (int[] secret : candidates) {
            if (exactMatches(secret, guess) == exactMatches) count++;
        }
        return count;
    }

    public void applyFeedback(int[] guess, int exactMatches) {
        if (guess == null || guess.length != size) throw new IllegalArgumentException("Bad guess");
        if (exactMatches < 0 || exactMatches > size) throw new IllegalArgumentException("Bad feedback");
        candidates.removeIf(secret -> exactMatches(secret, guess) != exactMatches);
    }

    public int[] chooseNextGuess() {
        if (candidates.isEmpty()) return null;
        if (candidates.size() == 1) {
            int[] only = candidates.get(0).clone();
            usedGuesses.add(key(only));
            return only;
        }

        // For the sizes Harpagia currently presents, evaluating the full permutation pool gives
        // better information than blindly taking the first surviving candidate. For a very large
        // pool, sample candidates to keep the phone responsive.
        List<int[]> pool;
        if (size <= 7 && allPermutations.size() <= 5040) {
            pool = allPermutations;
        } else {
            pool = candidates.size() <= 800 ? candidates : candidates.subList(0, 800);
        }

        int bestWorst = Integer.MAX_VALUE;
        long bestSquareSum = Long.MAX_VALUE;
        int[] best = null;
        boolean bestIsCandidate = false;

        for (int[] guess : pool) {
            if (usedGuesses.contains(key(guess))) continue;
            int[] buckets = new int[size + 1];
            int worst = 0;
            for (int[] secret : candidates) {
                int m = exactMatches(secret, guess);
                int v = ++buckets[m];
                if (v > worst) worst = v;
                if (worst > bestWorst) break;
            }
            if (worst > bestWorst) continue;

            long squareSum = 0L;
            for (int b : buckets) squareSum += (long) b * b;
            boolean isCandidate = containsCandidate(guess);

            if (best == null || worst < bestWorst ||
                    (worst == bestWorst && squareSum < bestSquareSum) ||
                    (worst == bestWorst && squareSum == bestSquareSum && isCandidate && !bestIsCandidate)) {
                bestWorst = worst;
                bestSquareSum = squareSum;
                best = guess.clone();
                bestIsCandidate = isCandidate;
            }
        }

        if (best == null) best = candidates.get(0).clone();
        usedGuesses.add(key(best));
        return best;
    }

    public boolean isCertain() { return candidates.size() == 1; }

    private boolean containsCandidate(int[] guess) {
        for (int[] c : candidates) {
            if (Arrays.equals(c, guess)) return true;
        }
        return false;
    }

    public static int exactMatches(int[] a, int[] b) {
        int n = Math.min(a.length, b.length);
        int c = 0;
        for (int i = 0; i < n; i++) if (a[i] == b[i]) c++;
        return c;
    }

    private static void permute(int[] a, int index, List<int[]> out) {
        if (index >= a.length) {
            out.add(a.clone());
            return;
        }
        for (int i = index; i < a.length; i++) {
            int t = a[index]; a[index] = a[i]; a[i] = t;
            permute(a, index + 1, out);
            t = a[index]; a[index] = a[i]; a[i] = t;
        }
    }

    private static String key(int[] a) {
        StringBuilder sb = new StringBuilder(a.length * 2);
        for (int v : a) sb.append((char) ('A' + v));
        return sb.toString();
    }
}
