package com.local.harpagiasanctum;

import android.Manifest;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 4101;
    private static final int REQ_NOTIFICATIONS = 4102;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable statusTicker = new Runnable() {
        @Override public void run() {
            refreshStatus();
            main.postDelayed(this, 800L);
        }
    };

    private TextView accessibilityStatus;
    private TextView captureStatus;
    private MediaProjectionManager projectionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        setContentView(buildUi());
        maybeRequestNotifications();
    }

    @Override protected void onResume() {
        super.onResume();
        main.removeCallbacks(statusTicker);
        main.post(statusTicker);
    }

    @Override protected void onPause() {
        main.removeCallbacks(statusTicker);
        super.onPause();
    }

    private View buildUi() {
        int pad = dp(20);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(Color.rgb(39, 58, 77));

        TextView title = text("Harpagia Sanctum Solver", 26, true);
        title.setTextColor(Color.WHITE);
        root.addView(title);

        TextView subtitle = text(
                "On-device solver for the Sanctum / Insight code puzzle. It detects the available number buttons, submits guesses, reads the green-check/red-X feedback, eliminates impossible codes, and chooses the next guess automatically.",
                16, false);
        subtitle.setTextColor(Color.rgb(220, 230, 238));
        subtitle.setPadding(0, dp(8), 0, dp(18));
        root.addView(subtitle);

        accessibilityStatus = statusText();
        root.addView(accessibilityStatus);

        Button accessibilityButton = button("1. Enable Sanctum accessibility service");
        accessibilityButton.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibilityButton);

        captureStatus = statusText();
        captureStatus.setPadding(0, dp(14), 0, dp(6));
        root.addView(captureStatus);

        Button captureButton = button("2. Start screen capture");
        captureButton.setOnClickListener(v -> startCapturePrompt());
        root.addView(captureButton);

        Button stopButton = button("Stop screen capture");
        stopButton.setOnClickListener(v -> {
            Intent i = new Intent(this, CaptureService.class);
            i.setAction(CaptureService.ACTION_STOP);
            startService(i);
            Toast.makeText(this, "Screen capture stopped.", Toast.LENGTH_SHORT).show();
            refreshStatus();
        });
        root.addView(stopButton);

        TextView usage = text(
                "How to use\n\n" +
                "• Enable the accessibility service once. Sideloaded apps may require Allow restricted settings in Android App info first.\n" +
                "• Start screen capture and choose the entire screen.\n" +
                "• Open Harpagia → Town → Sanctum and start a fresh puzzle. Keep the number row, Confirm button, and guess history visible.\n" +
                "• Tap the floating SANCTUM START button. The solver begins with the visible numbers in order (for example 0-1-2-3-4).\n" +
                "• After each result it reads the green-check and red-X counts, filters the remaining possible codes, and submits a new information-rich guess.\n" +
                "• Tap STOP at any time. Long-press the floating button to discard the current deduction history and start fresh.\n\n" +
                "Version 0.4 treats the code as a permutation of the blue numeric buttons: each shown number is used once. The gray ? button is intentionally ignored. Because of that rule, the solver only needs to read the green exact-position count; the red wrong-position count is inferred automatically as code length minus green.",
                15, false);
        usage.setTextColor(Color.WHITE);
        usage.setPadding(0, dp(20), 0, dp(10));
        root.addView(usage);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        return scroll;
    }

    private void startCapturePrompt() {
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "Enable the Harpagia Sanctum accessibility service first.", Toast.LENGTH_LONG).show();
        }
        Intent intent = projectionManager.createScreenCaptureIntent();
        startActivityForResult(intent, REQ_CAPTURE);
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode == RESULT_OK && data != null) {
            Intent service = new Intent(this, CaptureService.class);
            service.setAction(CaptureService.ACTION_START);
            service.putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode);
            service.putExtra(CaptureService.EXTRA_RESULT_DATA, data);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
            else startService(service);
            Toast.makeText(this, "Screen capture ready. Open Sanctum and tap SANCTUM START.", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Screen capture permission was not granted.", Toast.LENGTH_SHORT).show();
        }
        refreshStatus();
    }

    private void maybeRequestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    private void refreshStatus() {
        if (accessibilityStatus == null || captureStatus == null) return;
        boolean a11y = isAccessibilityEnabled();
        accessibilityStatus.setText(a11y ? "✓ Accessibility service enabled" : "○ Accessibility service not enabled");
        accessibilityStatus.setTextColor(a11y ? Color.rgb(114, 220, 125) : Color.rgb(255, 210, 90));

        boolean capturing = CaptureService.isRunning();
        captureStatus.setText(capturing ? "✓ Screen capture running" : "○ Screen capture not running");
        captureStatus.setTextColor(capturing ? Color.rgb(114, 220, 125) : Color.rgb(255, 210, 90));
    }

    private boolean isAccessibilityEnabled() {
        AccessibilityManager manager = (AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (manager == null) return false;
        List<AccessibilityServiceInfo> enabled = manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        ComponentName ours = new ComponentName(this, SanctumAccessibilityService.class);
        for (AccessibilityServiceInfo info : enabled) {
            if (info.getResolveInfo() == null || info.getResolveInfo().serviceInfo == null) continue;
            ComponentName c = new ComponentName(info.getResolveInfo().serviceInfo.packageName, info.getResolveInfo().serviceInfo.name);
            if (TextUtils.equals(c.flattenToString(), ours.flattenToString())) return true;
        }
        return false;
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        if (bold) v.setTypeface(v.getTypeface(), android.graphics.Typeface.BOLD);
        return v;
    }

    private TextView statusText() {
        TextView v = text("", 16, true);
        v.setGravity(Gravity.START);
        v.setPadding(0, dp(4), 0, dp(6));
        return v;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(15);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
