package com.local.harpagiasanctum;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Screen-only detector for the Sanctum number row, Confirm button, and feedback counts. */
public final class SanctumDetector {
    private static final int SAMPLE_STEP = 4;
    private static final int TEMPLATE_W = 24;
    private static final int TEMPLATE_H = 32;

    public static final class DetectionException extends Exception {
        DetectionException(String message) { super(message); }
    }

    public static final class Feedback {
        public final int green;
        public final int red;
        public final int rowY;
        Feedback(int green, int red, int rowY) {
            this.green = green;
            this.red = red;
            this.rowY = rowY;
        }
    }

    public static final class Layout {
        public final int count;
        public final float[] numberX;
        public final float numberY;
        public final float confirmX;
        public final float confirmY;
        public final int feedbackStartY;
        private final boolean[][] digitTemplates;

        Layout(int count, float[] numberX, float numberY, float confirmX, float confirmY,
               int feedbackStartY, boolean[][] digitTemplates) {
            this.count = count;
            this.numberX = numberX;
            this.numberY = numberY;
            this.confirmX = confirmX;
            this.confirmY = confirmY;
            this.feedbackStartY = feedbackStartY;
            this.digitTemplates = digitTemplates;
        }

        public Feedback readLatestFeedback(CaptureService.ScreenFrame frame) {
            int x0 = Math.max(0, (int) (frame.width * 0.70f));
            int x1 = Math.min(frame.width, (int) (frame.width * 0.90f));
            int y0 = Math.max(0, Math.min(feedbackStartY, (int) (frame.height * 0.55f)));
            // Always scan the whole visible history area. Harpagia can reposition/scroll the
            // history after several guesses, so a strictly increasing Y coordinate is not reliable.
            int y1 = Math.min(frame.height, (int) (frame.height * 0.945f));
            if (y1 <= y0 + 20) return null;

            List<Component> greens = fullComponents(frame, x0, y0, x1, y1, 1);
            List<Component> reds = fullComponents(frame, x0, y0, x1, y1, 2);
            if (greens.isEmpty() || reds.isEmpty()) return null;

            // The count digit is the right-hand component after the ✓ / X symbol.
            // Search from the lowest visible result row upward. Older rows do not need to remain visible.
            greens.sort((a, b) -> Integer.compare(b.cy(), a.cy()));
            for (Component gc : greens) {
                if (!looksLikeDigit(gc, frame)) continue;
                if (gc.cx() < frame.width * 0.755f) continue;

                Component bestRed = null;
                int bestDx = Integer.MAX_VALUE;
                for (Component rc : reds) {
                    if (!looksLikeDigit(rc, frame)) continue;
                    if (rc.cx() < frame.width * 0.755f) continue;
                    int dy = rc.cy() - gc.cy();
                    if (dy < 22 || dy > 60) continue;
                    int dx = Math.abs(rc.cx() - gc.cx());
                    if (dx <= 22 && dx < bestDx) {
                        bestDx = dx;
                        bestRed = rc;
                    }
                }
                if (bestRed == null) continue;

                int green = classifyColoredDigit(frame, gc, 1);

                // The blue buttons give us reliable templates for 0..N-1. We only need the green
                // exact-position count for deduction; because every guess uses all visible numbers
                // exactly once, red is mathematically N - green. This also handles G0 / XN without
                // ever trying to recognize the unavailable digit N from the red text.
                //
                // A solved G=N row is the one green value without a template. Detect that edge case
                // by checking that the paired red digit is 0.
                if (green < 0) {
                    int redForSolvedCheck = classifyColoredDigit(frame, bestRed, 2);
                    if (redForSolvedCheck == 0) green = count;
                }
                if (green < 0 || green > count) continue;
                int red = count - green;
                return new Feedback(green, red, gc.cy());
            }
            return null;
        }

        private int classifyColoredDigit(CaptureService.ScreenFrame frame, Component c, int mode) {
            boolean[] normalized = normalizeComponent(frame, c, mode);
            if (normalized == null) return -1;
            int best = -1;
            double bestScore = -1.0;
            for (int d = 0; d < digitTemplates.length; d++) {
                boolean[] t = digitTemplates[d];
                if (t == null) continue;
                double score = iou(normalized, t);
                if (score > bestScore) {
                    bestScore = score;
                    best = d;
                }
            }
            return bestScore >= 0.34 ? best : -1;
        }
    }

    public static Layout detect(CaptureService.ScreenFrame frame) throws DetectionException {
        List<Component> blue = sampledComponents(frame, 0);
        ArrayList<Component> candidates = new ArrayList<>();
        for (Component c : blue) {
            float wr = c.w / (float) frame.width;
            float hr = c.h / (float) frame.height;
            if (wr < 0.050f || wr > 0.150f) continue;
            if (hr < 0.035f || hr > 0.080f) continue;
            if (c.y < frame.height * 0.25f || c.y > frame.height * 0.72f) continue;
            if (c.samples < 45) continue;
            candidates.add(c);
        }
        if (candidates.size() < 3) throw new DetectionException("number buttons not found");

        // Group same-row, similarly-sized blue rectangles. The numeric buttons form the densest such row.
        ArrayList<Component> bestGroup = null;
        for (Component seed : candidates) {
            ArrayList<Component> group = new ArrayList<>();
            for (Component c : candidates) {
                if (Math.abs(c.cy() - seed.cy()) > frame.height * 0.018f) continue;
                if (Math.abs(c.h - seed.h) > frame.height * 0.012f) continue;
                if (Math.abs(c.w - seed.w) > frame.width * 0.025f) continue;
                group.add(c);
            }
            if (bestGroup == null || group.size() > bestGroup.size()) bestGroup = group;
        }
        if (bestGroup == null || bestGroup.size() < 3 || bestGroup.size() > 8) {
            throw new DetectionException("numeric row ambiguous");
        }
        bestGroup.sort(Comparator.comparingInt(a -> a.x));

        // Reject accidental groups that are not laid out at roughly even intervals.
        if (bestGroup.size() >= 3) {
            double avgGap = 0;
            for (int i = 1; i < bestGroup.size(); i++) avgGap += bestGroup.get(i).cx() - bestGroup.get(i - 1).cx();
            avgGap /= (bestGroup.size() - 1);
            for (int i = 1; i < bestGroup.size(); i++) {
                double gap = bestGroup.get(i).cx() - bestGroup.get(i - 1).cx();
                if (gap < avgGap * 0.70 || gap > avgGap * 1.30) throw new DetectionException("numeric spacing mismatch");
            }
        }

        int n = bestGroup.size();
        float[] xs = new float[n];
        float ySum = 0f;
        boolean[][] templates = new boolean[n][];
        for (int i = 0; i < n; i++) {
            Component c = bestGroup.get(i);
            xs[i] = c.cx();
            ySum += c.cy();
            templates[i] = extractWhiteDigitTemplate(frame, c);
            if (templates[i] == null) throw new DetectionException("digit label not readable");
        }
        float numberY = ySum / n;
        int numberBottom = 0;
        for (Component c : bestGroup) numberBottom = Math.max(numberBottom, c.y + c.h);

        // Find the large green Confirm button just below/right of the numeric row.
        List<Component> green = sampledComponents(frame, 3);
        Component confirm = null;
        for (Component c : green) {
            if (c.y < numberBottom || c.y > numberBottom + frame.height * 0.12f) continue;
            if (c.cx() < frame.width * 0.62f) continue;
            if (c.w < frame.width * 0.18f || c.h < frame.height * 0.035f) continue;
            if (confirm == null || c.samples > confirm.samples) confirm = c;
        }
        if (confirm == null) {
            // Conservative geometry fallback for the current Harpagia layout.
            float cx = frame.width * 0.807f;
            float cy = numberY + frame.height * 0.064f;
            int feedbackStart = (int) (cy + frame.height * 0.075f);
            return new Layout(n, xs, numberY, cx, cy, feedbackStart, templates);
        }

        int feedbackStart = (int) (confirm.cy() + frame.height * 0.075f);
        return new Layout(n, xs, numberY, confirm.cx(), confirm.cy(), feedbackStart, templates);
    }

    private static boolean[] extractWhiteDigitTemplate(CaptureService.ScreenFrame frame, Component button) {
        int x0 = button.x + button.w / 4;
        int x1 = button.x + button.w * 3 / 4;
        int y0 = button.y + button.h / 4;
        int y1 = button.y + button.h * 3 / 4;
        ArrayList<int[]> pts = new ArrayList<>();
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, maxX = -1, maxY = -1;
        for (int y = y0; y < y1; y++) {
            for (int x = x0; x < x1; x++) {
                int rgb = frame.rgb(x, y);
                if (!isWhiteText(rgb)) continue;
                pts.add(new int[]{x, y});
                if (x < minX) minX = x; if (x > maxX) maxX = x;
                if (y < minY) minY = y; if (y > maxY) maxY = y;
            }
        }
        if (pts.size() < 20 || maxX < minX || maxY < minY) return null;
        boolean[][] raw = new boolean[maxY - minY + 1][maxX - minX + 1];
        for (int[] p : pts) raw[p[1] - minY][p[0] - minX] = true;
        return normalize(raw);
    }

    private static boolean[] normalizeComponent(CaptureService.ScreenFrame frame, Component c, int mode) {
        int pad = 1;
        int x0 = Math.max(0, c.x - pad), x1 = Math.min(frame.width, c.x + c.w + pad);
        int y0 = Math.max(0, c.y - pad), y1 = Math.min(frame.height, c.y + c.h + pad);
        boolean[][] raw = new boolean[y1 - y0][x1 - x0];
        int count = 0;
        for (int y = y0; y < y1; y++) {
            for (int x = x0; x < x1; x++) {
                int rgb = frame.rgb(x, y);
                boolean hit = mode == 1 ? isGreenText(rgb) : isRedText(rgb);
                if (hit) { raw[y - y0][x - x0] = true; count++; }
            }
        }
        if (count < 20) return null;
        return normalize(raw);
    }

    private static boolean[] normalize(boolean[][] raw) {
        int h = raw.length, w = raw[0].length;
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) if (raw[y][x]) {
            if (x < minX) minX = x; if (x > maxX) maxX = x;
            if (y < minY) minY = y; if (y > maxY) maxY = y;
        }
        if (maxX < minX || maxY < minY) return null;
        int sw = maxX - minX + 1, sh = maxY - minY + 1;
        double scale = Math.min((TEMPLATE_W - 4.0) / sw, (TEMPLATE_H - 4.0) / sh);
        int dw = Math.max(1, (int) Math.round(sw * scale));
        int dh = Math.max(1, (int) Math.round(sh * scale));
        int ox = (TEMPLATE_W - dw) / 2;
        int oy = (TEMPLATE_H - dh) / 2;
        boolean[] out = new boolean[TEMPLATE_W * TEMPLATE_H];
        for (int yy = 0; yy < dh; yy++) {
            int sy = minY + Math.min(sh - 1, (int) Math.floor(yy / (double) dh * sh));
            for (int xx = 0; xx < dw; xx++) {
                int sx = minX + Math.min(sw - 1, (int) Math.floor(xx / (double) dw * sw));
                if (raw[sy][sx]) out[(oy + yy) * TEMPLATE_W + (ox + xx)] = true;
            }
        }
        return out;
    }

    private static double iou(boolean[] a, boolean[] b) {
        int inter = 0, union = 0;
        for (int i = 0; i < a.length && i < b.length; i++) {
            if (a[i] || b[i]) union++;
            if (a[i] && b[i]) inter++;
        }
        return union == 0 ? 0.0 : inter / (double) union;
    }

    private static boolean looksLikeDigit(Component c, CaptureService.ScreenFrame frame) {
        return c.w >= 4 && c.w <= frame.width * 0.045f &&
                c.h >= frame.height * 0.008f && c.h <= frame.height * 0.030f &&
                c.pixels >= 25 && c.pixels <= 500;
    }

    // mode: 0 blue button, 3 green button
    private static List<Component> sampledComponents(CaptureService.ScreenFrame frame, int mode) {
        int gw = (frame.width + SAMPLE_STEP - 1) / SAMPLE_STEP;
        int gh = (frame.height + SAMPLE_STEP - 1) / SAMPLE_STEP;
        byte[] mask = new byte[gw * gh];
        for (int gy = 0; gy < gh; gy++) {
            int y = Math.min(frame.height - 1, gy * SAMPLE_STEP + SAMPLE_STEP / 2);
            for (int gx = 0; gx < gw; gx++) {
                int x = Math.min(frame.width - 1, gx * SAMPLE_STEP + SAMPLE_STEP / 2);
                int rgb = frame.rgb(x, y);
                boolean hit = mode == 0 ? isBlueButton(rgb) : isGreenButton(rgb);
                if (hit) mask[gy * gw + gx] = 1;
            }
        }
        return componentsFromMask(mask, gw, gh, SAMPLE_STEP, 0, 0);
    }

    // mode: 1 green text, 2 red text
    private static List<Component> fullComponents(CaptureService.ScreenFrame frame,
                                                   int x0, int y0, int x1, int y1, int mode) {
        int w = Math.max(1, x1 - x0), h = Math.max(1, y1 - y0);
        byte[] mask = new byte[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int rgb = frame.rgb(x0 + x, y0 + y);
                boolean hit = mode == 1 ? isGreenText(rgb) : isRedText(rgb);
                if (hit) mask[y * w + x] = 1;
            }
        }
        return componentsFromMask(mask, w, h, 1, x0, y0);
    }

    private static List<Component> componentsFromMask(byte[] mask, int w, int h, int scale, int offX, int offY) {
        byte[] seen = new byte[mask.length];
        ArrayList<Component> out = new ArrayList<>();
        ArrayDeque<Integer> q = new ArrayDeque<>();
        int[] dx = {-1, 0, 1, -1, 1, -1, 0, 1};
        int[] dy = {-1, -1, -1, 0, 0, 1, 1, 1};
        for (int i = 0; i < mask.length; i++) {
            if (mask[i] == 0 || seen[i] != 0) continue;
            int minX = w, minY = h, maxX = -1, maxY = -1, count = 0;
            seen[i] = 1; q.add(i);
            while (!q.isEmpty()) {
                int p = q.removeFirst();
                int py = p / w, px = p - py * w;
                count++;
                if (px < minX) minX = px; if (px > maxX) maxX = px;
                if (py < minY) minY = py; if (py > maxY) maxY = py;
                for (int k = 0; k < 8; k++) {
                    int nx = px + dx[k], ny = py + dy[k];
                    if (nx < 0 || nx >= w || ny < 0 || ny >= h) continue;
                    int np = ny * w + nx;
                    if (mask[np] == 0 || seen[np] != 0) continue;
                    seen[np] = 1; q.add(np);
                }
            }
            if (count < 4) continue;
            int x = offX + minX * scale;
            int y = offY + minY * scale;
            int cw = (maxX - minX + 1) * scale;
            int ch = (maxY - minY + 1) * scale;
            Component c = new Component(x, y, cw, ch, count * scale * scale);
            c.samples = count;
            out.add(c);
        }
        return out;
    }

    private static boolean isBlueButton(int rgb) {
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        return r >= 20 && r <= 105 && g >= 90 && g <= 205 && b >= 140 && b <= 255 &&
                b >= g + 18 && g >= r + 30;
    }

    private static boolean isGreenButton(int rgb) {
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        return r >= 25 && r <= 115 && g >= 80 && g <= 195 && b >= 35 && b <= 140 &&
                g >= r + 16 && g >= b + 6;
    }

    private static boolean isWhiteText(int rgb) {
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        int max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        return r >= 170 && g >= 170 && b >= 170 && max - min <= 70;
    }

    private static boolean isGreenText(int rgb) {
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        return g >= 90 && g >= r + 18 && g >= b + 5 && r <= 135 && b <= 170;
    }

    private static boolean isRedText(int rgb) {
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        return r >= 105 && r >= g + 18 && r >= b + 8 && g <= 135 && b <= 145;
    }

    private static final class Component {
        final int x, y, w, h, pixels;
        int samples;
        Component(int x, int y, int w, int h, int pixels) {
            this.x = x; this.y = y; this.w = w; this.h = h; this.pixels = pixels;
        }
        int cx() { return x + w / 2; }
        int cy() { return y + h / 2; }
    }

    private SanctumDetector() {}
}
