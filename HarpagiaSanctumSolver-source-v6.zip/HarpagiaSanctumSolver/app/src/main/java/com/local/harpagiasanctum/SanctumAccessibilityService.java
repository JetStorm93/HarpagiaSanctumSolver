package com.local.harpagiasanctum;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.Toast;

public class SanctumAccessibilityService extends AccessibilityService implements CaptureService.FrameListener {
    private static final long TAP_DURATION_MS = 45L;
    private static final long BETWEEN_DIGITS_MS = 115L;
    private static final long BEFORE_CONFIRM_MS = 100L;
    private static final long AFTER_CONFIRM_IGNORE_MS = 300L;
    private static final long FEEDBACK_SCAN_INTERVAL_MS = 35L;
        private static final long NEXT_GUESS_DELAY_MS = 25L;
    private static final long DETECT_INTERVAL_MS = 90L;

    private enum State { OFF, DETECTING, SUBMITTING, WAITING_RESULT, THINKING }

    private final Object stateLock = new Object();
    private final Handler main = new Handler(Looper.getMainLooper());

    private WindowManager windowManager;
    private Button controlButton;
    private WindowManager.LayoutParams overlayParams;

    private volatile State state = State.OFF;
    private SanctumDetector.Layout layout;
    private PermutationSolver solver;
    private int[] currentGuess;
    private int guessNumber;
    private int runToken;
    private int pendingFeedbackGreen = -1;
    private int pendingFeedbackRowY = -1;
    private int pendingFeedbackStableReads = 0;
    private int impossibleFeedbackRetries = 0;
    private long confirmSubmittedAt;
    private long resultReadableAfter;
    private long lastFeedbackScan;
    private long lastDetectAttempt;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        CaptureService.setFrameListener(this);
        showOverlay();
    }

    private void showOverlay() {
        if (controlButton != null) return;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (windowManager == null) return;

        controlButton = new Button(this);
        controlButton.setText("SANCTUM\nSTART");
        controlButton.setTextColor(Color.WHITE);
        controlButton.setTextSize(10);
        controlButton.setAllCaps(false);
        controlButton.setGravity(Gravity.CENTER);
        controlButton.setPadding(dp(4), 0, dp(4), 0);
        applyButtonColor(Color.rgb(19, 132, 112));
        controlButton.setOnClickListener(v -> toggle());
        controlButton.setOnLongClickListener(v -> {
            restartFresh();
            return true;
        });

        overlayParams = new WindowManager.LayoutParams(
                dp(116),
                dp(68),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                android.graphics.PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.START;
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        overlayParams.x = Math.max(dp(8), screenWidth - dp(126));
        overlayParams.y = dp(190);
        windowManager.addView(controlButton, overlayParams);
    }

    private void toggle() {
        if (state == State.OFF) startSolver();
        else stopSolver("Sanctum solver stopped.");
    }

    private void restartFresh() {
        if (state == State.OFF) {
            startSolver();
            return;
        }
        synchronized (stateLock) {
            runToken++;
            state = State.DETECTING;
            layout = null;
            solver = null;
            currentGuess = null;
            guessNumber = 0;
            pendingFeedbackGreen = -1;
            pendingFeedbackRowY = -1;
            pendingFeedbackStableReads = 0;
            impossibleFeedbackRetries = 0;
            confirmSubmittedAt = 0L;
            lastDetectAttempt = 0L;
        }
        setButton("STOP\nFIND…", Color.rgb(220, 145, 35));
        toast("Deduction history cleared. Start from a fresh Sanctum puzzle.");
    }

    private void startSolver() {
        if (!CaptureService.isRunning()) {
            toast("Open Harpagia Sanctum Solver and start screen capture first.");
            return;
        }
        synchronized (stateLock) {
            runToken++;
            state = State.DETECTING;
            layout = null;
            solver = null;
            currentGuess = null;
            guessNumber = 0;
            pendingFeedbackGreen = -1;
            pendingFeedbackRowY = -1;
            pendingFeedbackStableReads = 0;
            impossibleFeedbackRetries = 0;
            confirmSubmittedAt = 0L;
            lastDetectAttempt = 0L;
        }
        CaptureService.setFrameListener(this);
        setButton("STOP\nFIND…", Color.rgb(220, 145, 35));
    }

    private void stopSolver(String message) {
        synchronized (stateLock) {
            runToken++;
            state = State.OFF;
            layout = null;
            solver = null;
            currentGuess = null;
            guessNumber = 0;
            pendingFeedbackGreen = -1;
            pendingFeedbackRowY = -1;
            pendingFeedbackStableReads = 0;
            impossibleFeedbackRetries = 0;
            confirmSubmittedAt = 0L;
        }
        setButton("SANCTUM\nSTART", Color.rgb(19, 132, 112));
        if (message != null) toast(message);
    }

    @Override
    public void onFrame(CaptureService.ScreenFrame frame) {
        State local = state;
        if (local == State.OFF || local == State.SUBMITTING || local == State.THINKING) return;

        long now = SystemClock.elapsedRealtime();
        if (local == State.DETECTING) {
            if (now - lastDetectAttempt < DETECT_INTERVAL_MS) return;
            lastDetectAttempt = now;
            detectAndBegin(frame);
            return;
        }

        if (local == State.WAITING_RESULT) {
            if (now < resultReadableAfter || now - lastFeedbackScan < FEEDBACK_SCAN_INTERVAL_MS) return;
            lastFeedbackScan = now;
            readResult(frame);
        }
    }

    private void detectAndBegin(CaptureService.ScreenFrame frame) {
        try {
            SanctumDetector.Layout found = SanctumDetector.detect(frame);
            if (found.count < 3 || found.count > 8) return;

            // Start immediately once the puzzle controls are found. The feedback reader always
            // chooses the lowest/newest visible result row, so a costly pre-scan of old history is
            // unnecessary and only delays the first guess.
            int[] first;
            int token;
            synchronized (stateLock) {
                if (state != State.DETECTING) return;
                layout = found;
                solver = new PermutationSolver(found.count);
                first = solver.firstGuess();
                currentGuess = first;
                guessNumber = 1;
                pendingFeedbackGreen = -1;
                pendingFeedbackRowY = -1;
                pendingFeedbackStableReads = 0;
                impossibleFeedbackRetries = 0;
                confirmSubmittedAt = 0L;
                state = State.SUBMITTING;
                token = runToken;
            }
            setButton("STOP " + found.count + "#\nGUESS 1", Color.rgb(29, 118, 210));
            toast("Sanctum detected: " + found.count + " positions. Submitting first guess.");
            final int[] firstCopy = first.clone();
            final int run = token;
            main.post(() -> submitGuess(firstCopy, 0, run));
        } catch (SanctumDetector.DetectionException ignored) {
            // Keep looking while the user navigates to the puzzle.
        } catch (Throwable t) {
            stopSolver("Sanctum detection failed. Long-press START to retry.");
        }
    }

    private void submitGuess(int[] guess, int index, int token) {
        SanctumDetector.Layout l = layout;
        synchronized (stateLock) {
            if (state != State.SUBMITTING || token != runToken || l == null) return;
        }

        if (index < guess.length) {
            int digit = guess[index];
            if (digit < 0 || digit >= l.numberX.length) {
                stopSolver("Solver generated an unavailable number.");
                return;
            }
            setButton("STOP " + l.count + "#\nTAP " + (index + 1) + "/" + guess.length,
                    Color.rgb(29, 118, 210));
            dispatchTap(l.numberX[digit], l.numberY, () ->
                    main.postDelayed(() -> submitGuess(guess, index + 1, token), BETWEEN_DIGITS_MS));
            return;
        }

        setButton("STOP\nCONFIRM", Color.rgb(29, 118, 210));
        main.postDelayed(() -> dispatchTap(l.confirmX, l.confirmY, () -> {
            synchronized (stateLock) {
                if (state != State.SUBMITTING || token != runToken) return;
                state = State.WAITING_RESULT;
                confirmSubmittedAt = SystemClock.elapsedRealtime();
                resultReadableAfter = confirmSubmittedAt + AFTER_CONFIRM_IGNORE_MS;
                lastFeedbackScan = 0L;
                pendingFeedbackGreen = -1;
                pendingFeedbackRowY = -1;
                pendingFeedbackStableReads = 0;
                impossibleFeedbackRetries = 0;
            }
            setButton("STOP\nREAD…", Color.rgb(220, 145, 35));
        }), BEFORE_CONFIRM_MS);
    }

    private void readResult(CaptureService.ScreenFrame frame) {
        SanctumDetector.Layout l = layout;
        PermutationSolver s = solver;
        int[] guess = currentGuess;
        if (l == null || s == null || guess == null) return;

        SanctumDetector.Feedback f = l.readLatestFeedback(frame);
        if (f == null) return;
        if (f.green < 0 || f.green > l.count) return;

        // IMPORTANT: never depend on any older result row remaining visible. Harpagia may
        // scroll/reposition the history as it grows. The solver already remembers every prior
        // guess and score internally; for this round we only need the newest visible feedback.
        // Require two consecutive matching reads so a partially animated/scrolling row is not
        // accepted from a single frame.
        if (f.green == pendingFeedbackGreen && Math.abs(f.rowY - pendingFeedbackRowY) <= 18) {
            pendingFeedbackStableReads++;
        } else {
            pendingFeedbackGreen = f.green;
            pendingFeedbackRowY = f.rowY;
            pendingFeedbackStableReads = 1;
            return;
        }
        if (pendingFeedbackStableReads < 2) return;

        if (f.green == l.count) {
            stopSolver("Solved in " + guessNumber + " guesses.");
            return;
        }

        // A transient bad read should not destroy the deduction state. Check the score against
        // the current candidate set before mutating it. If it would make the puzzle impossible,
        // keep watching for a corrected/stable row instead of immediately stopping.
        int wouldRemain = s.remainingIfFeedback(guess, f.green);
        if (wouldRemain <= 0) {
            impossibleFeedbackRetries++;
            pendingFeedbackGreen = -1;
            pendingFeedbackRowY = -1;
            pendingFeedbackStableReads = 0;
            resultReadableAfter = SystemClock.elapsedRealtime() + 90L;
            if (impossibleFeedbackRetries >= 8) {
                stopSolver("Feedback could not be read consistently. Send a screenshot of the newest result row.");
            }
            return;
        }

        synchronized (stateLock) {
            if (state != State.WAITING_RESULT) return;
            state = State.THINKING;
        }
        setButton("STOP\nTHINK…", Color.rgb(126, 85, 180));

        try {
            s.applyFeedback(guess, f.green);
            int remaining = s.remainingCount();
            int[] next = s.chooseNextGuess();
            if (next == null) {
                stopSolver("No next guess could be generated.");
                return;
            }

            int token;
            synchronized (stateLock) {
                if (state != State.THINKING) return;
                currentGuess = next;
                guessNumber++;
                state = State.SUBMITTING;
                token = runToken;
            }
            int red = l.count - f.green;
            setButton("STOP G" + f.green + " X" + red + "\n" + remaining + " LEFT",
                    s.isCertain() ? Color.rgb(44, 150, 84) : Color.rgb(29, 118, 210));
            final int[] nextCopy = next.clone();
            final int run = token;
            main.postDelayed(() -> submitGuess(nextCopy, 0, run), NEXT_GUESS_DELAY_MS);
        } catch (Throwable t) {
            stopSolver("Deduction error. Send a screenshot of the current Sanctum board.");
        }
    }

    private void dispatchTap(float x, float y, Runnable after) {
        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x + 0.1f, y + 0.1f);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, TAP_DURATION_MS))
                .build();
        boolean accepted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription gestureDescription) {
                if (after != null) after.run();
            }

            @Override
            public void onCancelled(GestureDescription gestureDescription) {
                stopSolver("Android cancelled a Sanctum tap.");
            }
        }, main);
        if (!accepted) stopSolver("Android rejected a Sanctum tap.");
    }

    @Override
    public void onCaptureStopped() {
        main.post(() -> stopSolver("Screen capture stopped. Start it again in Harpagia Sanctum Solver."));
    }

    private void setButton(String text, int color) {
        main.post(() -> {
            if (controlButton == null) return;
            controlButton.setText(text);
            applyButtonColor(color);
        });
    }

    private void applyButtonColor(int color) {
        if (controlButton == null) return;
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), Color.argb(185, 255, 255, 255));
        controlButton.setBackground(bg);
    }

    private void toast(String text) {
        main.post(() -> Toast.makeText(this, text, Toast.LENGTH_LONG).show());
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        // Screen analysis is intentionally performed through MediaProjection rather than app internals.
    }

    @Override public void onInterrupt() {}

    @Override
    public void onDestroy() {
        CaptureService.setFrameListener(null);
        synchronized (stateLock) {
            state = State.OFF;
            runToken++;
        }
        if (controlButton != null && windowManager != null) {
            try { windowManager.removeView(controlButton); } catch (Throwable ignored) {}
            controlButton = null;
        }
        super.onDestroy();
    }
}
