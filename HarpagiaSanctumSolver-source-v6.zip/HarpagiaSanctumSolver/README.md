# Harpagia Sanctum Solver

Private Android helper for Harpagia's Sanctum / Insight code puzzle.

## What v0.6 does
- Uses MediaProjection to read only the visible screen.
- Uses an AccessibilityService only to show a floating START/STOP button and dispatch taps.
- Dynamically finds the row of blue numeric buttons and the green Confirm button.
- Ignores the gray `?` button.
- Starts with the visible numbers in order, e.g. `0 1 2 3 4`.
- Reads both the green-check exact-position count and red-X wrong-position count from the newest guess-history row using color/shape matching; no OCR library is required.
- Handles edge counts such as X5/G0 even though 5 is not one of the visible 0-4 button templates.
- Filters all remaining permutation candidates consistent with the feedback.
- Chooses a next guess by minimizing the largest possible remaining candidate bucket (with a secondary expected-size tie break).
- Repeats until solved or stopped.

## Current rule assumption
This build assumes each visible blue number is used exactly once in the hidden code. Under that rule, green + red always equals the code length. v0.5 reads both values and verifies that relationship before using the result. If Harpagia ever reports a total smaller than the code length, the solver stops with a clear rule-mismatch message instead of making incorrect deductions.

The detector was checked against the supplied 709x1536 Sanctum screenshots: it found the 5 numeric buttons, Confirm button, and read the shown feedback as green=3 / red=2.

## Build
The project targets Android SDK 35 and Java 17. The included debug signing key is intentionally stable so future APKs from this project can update the installed app instead of conflicting with a new ephemeral GitHub Actions debug key.


## v0.2 fixes
- Fixes `✓0 / X5` being misread as `✓0 / X0`.
- Removes the unnecessary old-feedback pre-scan so the first guess begins sooner after START.


## v0.3.0
- Moved the floating solver control about 65 dp higher so it blocks less of the Sanctum UI.


## v0.5.0
- Keeps the immediate left-to-right first guess (`0 1 2 ...`).
- Removes the fragile requirement that every new feedback row must be lower on screen than the prior row. This fixes the apparent stop/freeze after the history grows to about five guesses and Harpagia repositions the history.
- Scans the full visible feedback-history area and has a timed fallback for rows that move or reuse the same screen position.
- Cuts fixed post-confirm/next-guess waits so the solver reacts much faster after a result appears.
- Shows the interpreted feedback on the floater (`G# X#`) plus the number of candidate codes left.
- There is no five-guess cap. For a 5-position permutation puzzle the deduction engine may legitimately need a sixth guess for some codes.


## v0.5 feedback fix

- Reverted the fragile independent red-counter OCR introduced in v0.4.
- The green exact-position count is authoritative; red is derived as N - green.
- Keeps the v0.4 history-reposition handling so the solver can continue beyond five rows.
- Shorter post-confirm, feedback-scan, and next-guess delays for faster response.


## v0.6 history-scroll fix
- The solver no longer uses the prior result row's screen position or visibility to validate a new result.
- All prior guesses and feedback remain in the solver's internal deduction state, so Harpagia can scroll old rows completely off-screen without losing context.
- After Confirm, only the newest/bottom-most visible feedback row is used for that round.
- Requires two consecutive matching reads before accepting a feedback value, reducing errors while the history is animating or scrolling.
- A suspicious read that would eliminate every remaining candidate is retried instead of immediately destroying the run.
- Extends the feedback scan farther down the screen so a newest row near the bottom edge can still be read.
